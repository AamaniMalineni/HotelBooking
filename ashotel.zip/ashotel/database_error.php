<?php
echo"error in connection of database";
?>